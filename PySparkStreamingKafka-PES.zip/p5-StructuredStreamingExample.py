#Structured Streaming Example

# Run pyspark sheel using the command
# pyspark --master local[*]

# Open another terminal and Create a directory named sparkstreaming in local file system home directory i.e. /home/hadoop

# from pyspark.sql import SparkSession

from pyspark.sql.functions import *
from pyspark.sql.types import *

# create sparksession
# spark = SparkSession.builder.appName("StructStream").getOrCreate()

# creating Schema
# structured Streaming proccesing always requires the specification of a schema for the data in the stream
schema = StructType([StructField('emp_id', IntegerType(), True),
                   StructField('emp_name', StringType(), True),
                   StructField('job_name', StringType(), True),
                   StructField('manager_id', IntegerType(), True),
                   StructField('salary', DoubleType(), True),
                   StructField('dept_name', StringType(), True)])

# creating Streaming Dataframe that would read the data from a given folder

employee = spark.readStream.schema(schema).option("header", True).option("sep", ",").csv("file:///home/hadoop/sparkstreaming/")

# query to find the total count of employees in a particular profession
employee.groupBy("job_name").count().writeStream.format('console').outputMode('complete').start().awaitTermination()

# Let us simulate streaming data in the above directory
# Transfer the file data1.csv to the above directory /home/hadoop/sparkstreaming/
# groupby operation will start and the result will be displayed

# Now you will notice the groupby operation is run by spark on the existing data and result gets displayed

# Now transfer the second file data2.csv to the above directory
# The groupby computation will get started again by spark structured streaming and the result including the previous data is displayed again.

# We can trnsfer the other data csv files one by one. Each time we transfer a file the stream is read and the computation is performed.
# Since we specified output mode as complete the complete data is taken for the computation i.e. the group by aggregation.
