# Start pyspark shell using the command pyspark --master local[*]

# Open another terminal and give the comand below
# $ nc -lk 9999
# If port number 9999 is being used then use port number 7777 in nc command and in the code below

# Import the necessary classes

# from pyspark.sql import SparkSession

from pyspark.sql.functions import explode
from pyspark.sql.functions import split

# Create a SparkSession, the starting point of all functionalities related to Spark.

# spark = SparkSession.builder.appName("StructuredNetworkWordCount").getOrCreate()

# Create DataFrame representing the stream of input lines from connection to localhost:9999

lines = spark.readStream.format("socket").option("host", "localhost").option("port", 9999).load()

type(lines)

# Split the lines into words
words = lines.select(
   explode(
       split(lines.value, " ")
   ).alias("word")
)

# Generate running word count
wordCounts = words.groupBy("word").count()

# Start running the query that prints the running counts to the console
query = wordCounts.writeStream.outputMode("complete").format("console").start()

query.awaitTermination()

####
This lines DataFrame represents an unbounded table containing the streaming text data.

This table contains one column of strings named “value”, and each line in the streaming text data becomes a row in the table.

Note, that at that point it is not currently receiving any data as we are just setting up the transformation, and have not yet started it.

Next, we have used two built-in SQL functions - split and explode, to split each line into multiple rows with a word each.
And we use the function alias to name the new column as “word”.

Finally, we have defined the wordCounts DataFrame using group by to get the unique values in the Dataset and counting them.

Note that this is a streaming DataFrame which represents the running word counts of the stream.

We have now set up the query on the streaming data.

Now we actually have to start receiving data and computing the counts.

To do this, we set it up to print the complete set of counts (specified by outputMode("complete")) to the console every time they are updated.

And then start the streaming computation using start().
####
