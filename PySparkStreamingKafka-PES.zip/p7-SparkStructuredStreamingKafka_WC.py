# pyspark --master local[*] --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.1.2

# Import the necessary classes

# from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
from pyspark.sql.functions import split

# Create a SparkSession, the starting point of all functionalities related to Spark.

# spark = SparkSession.builder.appName("StructuredNetworkWordCount").getOrCreate()

# Create DataFrame representing the stream of input lines from Kafka topic named first-topic

lines = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "first-topic").load()

lines.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

# Split the lines into words
words = lines.select(
   explode(
       split(lines.value, " ")
   ).alias("word")
)

# Generate running word count
wordCounts = words.groupBy("word").count()

# Start running the query that prints the running counts to the console
query = wordCounts.writeStream.outputMode("complete").format("console").start()

query.awaitTermination()

# Let us open another terminal using putty or ssh
# Run Kafka console producer and publish some lines to the topic
# The groupby computation will get statrted again by spark structured streaming and the result including the previous data is displayed again.
