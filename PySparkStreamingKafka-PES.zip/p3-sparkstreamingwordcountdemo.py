# Run the following lines of Python code from PySpark Shell by starting pyspark shell as below.
# $ pyspark --master local[*]
# In the pyspark shell prompt you can copy& paste the python code line by line
# starting from importing spark streaing context

# Open one more duplicate putty or ssh terminal
# In the second terminal give the following command
# $ nc -lk 9999
# And enter the following sample lines of text for testing
#   line one to test spark streaming test spark streaming
#   line two to test streaming spark streaming test
# Check the first terminal in pyspark shell 
# Wordcount can be seen on data streaming from port 9999

# As pyspark shell creates spark context as sc when we start it, no need to import pyspark.
# And no need to create spark context object

# In case by mistake we started pyspark shell with --master local[1] then 
# stop spark context which was automatically created by pyspark shell
# And create a new one as in the two lines below.
# sc.stop()
# sc = SparkContext("local[2]", "StreamingWordCount")

# Import streaming context library from pyspark streaming package
from pyspark.streaming import StreamingContext

# Create Spark Streaming Context with 1 second time interval
ssc = StreamingContext(sc, 1)

# Create a DStream that will connect to hostname:port, like localhost:9999
lines = ssc.socketTextStream("localhost", 9999)
type(lines)

# Split each line into words DStream
words = lines.flatMap(lambda line: line.split(" "))
type(words)

pairs = words.map(lambda word: (word, 1))
wordCounts = pairs.reduceByKey(lambda x, y: x + y)

# Print the elements of each RDD generated in this DStream to the console i.e. wordCounts
wordCounts.pprint()

ssc.start()
ssc.awaitTermination()

ssc.stop()
sc.stop()
