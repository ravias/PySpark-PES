lines = sc.textFile("war_and_peace.txt",4)
type(lines)

lines.count()

lines.first()
type(lines.first())

lines.take(5)

lines.getNumPartitions()

def count_in_a_partition(iterator):
    yield sum(1 for _ in iterator)

lines.mapPartitions(count_in_a_partition).collect()

nonNullLines = lines.filter(lambda line: len(line)>0)
type(nonNullLines)

nonNullLines.count()

nonNullLines.first()
type(nonNullLines.first())

nonNullLines.take(5)

words = nonNullLines.flatMap(lambda line: line.split())
type(words)

words.count()

words.first()
type(words.first())

words.take(5)

upperWords = words.map(lambda word: word.upper())
type(upperWords)

upperWords.count()

upperWords.first()
type(upperWords.first())

upperWords.take(5)

pairedOnes = upperWords.map(lambda uw: (uw, 1))
type(pairedOnes)

pairedOnes.count()

pairedOnes.first()
type(pairedOnes.first())

pairedOnes.take(5)

wordCounts = pairedOnes.reduceByKey(lambda prev, next: prev + next)
type(wordCounts)

wordCounts.count()

wordCounts.first()
type(wordCounts.first())

wordCounts.take(5)

for word in wordCounts.take(5):
    print("*****", word)


# We can also create an RDD from an existing collection of data elements using parallelize method of SparkContext.

data = [1, 2, 3, 4, 5]
type(data)

distData = sc.parallelize(data,2)

type(distData)

distData.getNumPartitions()
