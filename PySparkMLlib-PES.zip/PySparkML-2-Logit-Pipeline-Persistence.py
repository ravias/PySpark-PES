###
# The following lines are required when you use an IDE other than pyspark shell such as PyCharm or Jupyter notebook.

import findspark
findspark.init('<>')

###

import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Python Linear Regression example").getOrCreate()

###

# Here is another way to the above

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

sc = SparkContext.getOrCreate()
spark = SparkSession(sc) 

###

# Read data

file_location = "HeartStroke.csv"
file_type = "csv"

# CSV options
infer_schema = True
first_row_is_header = True
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
rawstrokeDF = spark.read.format(file_type)   .option("inferSchema", infer_schema)   .option("header", first_row_is_header)   .option("sep", delimiter)   .load(file_location)

# It is the same as the above
# rawstrokeDF = spark.read.format('csv').option("inferSchema", True).option("header", True).option("sep",',').load("HeartStroke.csv")

rawstrokeDF.show(5, False)

rawstrokeDF.count()

rawstrokeDF.printSchema()

# ## Check missing values
# (For this exercise we will drop all the na values)

from pyspark.sql.functions import isnull, when, count, col

rawstrokeDF.describe().show()

rawstrokeDF.filter(col('smoking_history').isNull()).count()
rawstrokeDF.filter(col('BMI').isNull()).count()

rawstrokeDF.filter(col('smoking_history').isNull()).select(count('*')).show()
rawstrokeDF.filter(col('BMI').isNull()).select(count('*')).show()

rawstrokeDF.columns

rawstrokeDF.select([count(when(isnull(c), c)).alias(c) for c in rawstrokeDF.columns]).show()

# The columns 'smoking history' and 'BMI' has missing values. Let's drop them

# Use df_name.na.drop() to drop all the null values from the dataframe
rawstrokeDF = rawstrokeDF.na.drop()

# Check if the null value still exist
rawstrokeDF.select([count(when(isnull(c), c)).alias(c) for c in rawstrokeDF.columns]).show()

rawstrokeDF.show(5, False)

# ## Check and confirm the data type of each column

rawstrokeDF.printSchema()

# The variable values for any supervised ML algorithm has to be of type double. Let us convert the columns "diabetes", "hypertension" and target varaible "stroke" data type into type double

from pyspark.sql.types import DoubleType
# from pyspark.sql.functions import col
intcols = ["diabetes", "hypertension"]

for col_name in intcols:
    strokeDF = rawstrokeDF.withColumn(col_name, col(col_name).cast(DoubleType()))

# We will also rename the column name 'stroke' as 'label' for 

strokeDF.printSchema()

# We will split the stroke df into train and test split and pass the training set to the pipeline

# We spilt the data into 70-30 set
# Training Set - 70% obesevations
# Testing Set - 30% observations

trainDF, testDF =  assembledDF.randomSplit([0.7,0.3], seed = 2020)

# print the count of observations in each set

print("Observations in training set = ", trainDF.count())
print("Observations in testing set = ", testDF.count())


# ## Transformations

# #### Binarizer
# Let us use divide the BMi into two groups: Obese and healthy. 1 represents 'obese' and 0 represents 'healthy' (If your BMI is 30.0 or higher, it falls within the obese range)
# We will use the Binarizer transformer to create a new variable 'Body Type' (1- obese and 0- healthy) by binarizing the 'BMI' variable by setting the obesity threshold value 30.0. Binarization is used for thresholding numerical feature to binary feature (0 or 1)

from pyspark.ml.feature import Binarizer
binarizer = Binarizer(inputCol="BMI", outputCol="BodyType", threshold=30.0)

# #### Bucketizer
# We now group the patients based on their age group. Here, we will use the Bucketizer transformer. Bucketizer is used for creating group of values of a continuous feature

from pyspark.ml.feature import Bucketizer
# lets define the age age group splits
splits = [0, 25.0, 50.0, 75.0, 100.0]
bucketizer = Bucketizer(inputCol="age", outputCol="ageGroup", splits=splits)

# #### StringIndexer
# There are three categorical variables in our dataset viz., 'gender', 'heart disease' and 'smoking history'. These variables cannot be directly passed to our ML algorithms. We will converet them into indexes and to do that we will use StringIndexer transformer. StringIndexer converts a string column to an index column. The most frequent label gets index 0

from pyspark.ml.feature import StringIndexer
indexers = StringIndexer(inputCols= ['stroke','gender', 'heart_disease', 'smoking_history'], 
                         outputCols=['label', 'gender_indexed', 'heart_disease_indexed', 'smoking_history_indexed'])

# ### VectorAssembler
# MLlib expects all features to be contained within a single column. VectorAssembler combines multiple columns and gives single column as output

# Import VectorAssembler from pyspark.ml.feature package

from pyspark.ml.feature import VectorAssembler

# Create a list of all the variables that are required in features vector
# These features are then further used for training model

features_col = ["age", "diabetes", "hypertension", "BMI", "BodyType", "ageGroup", 
                "gender_indexed","heart_disease_indexed","smoking_history_indexed"]

# Create the VectorAssembler object

assembler = VectorAssembler(inputCols= features_col, outputCol= "features")

# ### Supervised Learning - Classification 
# #### Logistic Regression

# import the LogisticRegression function from the pyspark.ml.classification package
from pyspark.ml.classification import LogisticRegression

# Build the LogisticRegression object 'lr' by setting the required parameters
lr = LogisticRegression(featuresCol="features", labelCol="label",maxIter= 10,regParam=0.3, elasticNetParam=0.8)

### Building Pipeline

# import Pipeline from pyspark.ml package

from pyspark.ml import Pipeline

# Build the pipeline object by providing stages(transformers + Estimator) 
# that you need the dataframe to pass through
# Transformers - binarizer, bucketizer, indexers, assembler
# Estimator - lr

lrpipeline = Pipeline(stages=[binarizer, bucketizer, indexers, assembler, lr])

# fit the pipeline for the trainind data
lrpipelinemodel = lrpipeline.fit(trainDF)

# transform the data
lrpipelinepredicted = lrpipelinemodel.transform(testDF)

# view some of the columns generated
lrpipelinepredicted.select('label', 'rawPrediction', 'probability', 'prediction').show(10)

# ##### Model Evaluation

# import BinaryClassificationEvaluator from the pyspark.ml.evaluation package
from pyspark.ml.evaluation import BinaryClassificationEvaluator

# Build the BinaryClassificationEvaluator object 'evaluator'
evaluator = BinaryClassificationEvaluator()

# Create model summary object
lrpipelinemodelSummary = lrpipelinemodel.summary

# Print the following metrics one by one: 
# 1. Accuracy
# Accuracy is a model summary parameter
print("Accuracy = ", lrpipelinemodelSummary.accuracy)
# 2. Area under the ROC curve
# Area under the ROC curve is a model summary parameter
print("Area under the ROC curve = ", lrpipelinemodelSummary.areaUnderROC)
# 3. Precision (Positive Predictive Value)
# Precision is a model summary parameter
print("Precision = ", lrpipelinemodelSummary.weightedPrecision)
# 4. Recall (True Positive Rate)
# Recall is a model summary parameter
print("Recall = ", lrpipelinemodelSummary.weightedRecall)

# ### Model Persistence
# Model persistence means saving your model to a disk. After you finalize your model for prediction depending upon the performance, you need to save the model to the disk. Let's say, you finalize 'lrpipelinemodel' to be used for in production environment i.e. in your application. We use the following code to save it.

# ##### Saving pipeline model

# use save() method to save the model
# write().overwrite() is usually used when you want to replace the older model with a new one
# It might happen that you wish to retrain your model and save it at the same the place
lrpipelinemodel.write().overwrite().save("lrpipelinemodel")

# ##### Loading pipeline model

# import PipelineModel from pyspark.ml package
from pyspark.ml import PipelineModel

# load the model from the location it is stored
# The loaded model acts as PipelineModel
pipemodel = PipelineModel.load("lrpipelinemodel")

# use the PipelineModel object to perform prediciton on test data. 
# Use .transform() to perfrom prediction
prediction = pipemodel.transform(testDF)

# print the results
prediction.select('label', 'rawPrediction', 'probability', 'prediction').show(5)
