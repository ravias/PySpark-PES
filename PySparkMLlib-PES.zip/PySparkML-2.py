###
# The following lines are required when you use an IDE other than pyspark shell such as PyCharm or Jupyter notebook.

import findspark
findspark.init('<>')

###

import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("Python Linear Regression example").getOrCreate()

###

# Here is another way to the above

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

sc = SparkContext.getOrCreate()
spark = SparkSession(sc) 

###

# Read data

file_location = "HeartStroke.csv"
file_type = "csv"

# CSV options
infer_schema = True
first_row_is_header = True
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
rawstrokeDF = spark.read.format(file_type)   .option("inferSchema", infer_schema)   .option("header", first_row_is_header)   .option("sep", delimiter)   .load(file_location)


rawstrokeDF.show(5, False)


# ## Check missing values
# (For this exercise we will drop all the na values)

from pyspark.sql.functions import isnull, when, count, col
rawstrokeDF.select([count(when(isnull(c), c)).alias(c) for c in rawstrokeDF.columns]).show()


# The columns 'smoking history' and 'BMI' has missing values. Let's drop them

# Use df_name.na.drop() to drop all the null values from the dataframe
rawstrokeDF = rawstrokeDF.na.drop()


# Check if the null value still exist
from pyspark.sql.functions import isnull, when, count, col
rawstrokeDF.select([count(when(isnull(c), c)).alias(c) for c in rawstrokeDF.columns]).show()


rawstrokeDF.show(5, False)


# ## Check and confirm the data type of each column

rawstrokeDF.printSchema()


# The variable values for any supervised ML algorithm has to be of type double. Let us convert the columns "diabetes", "hypertension" and target varaible "stroke" data type into type double

from pyspark.sql.types import DoubleType
from pyspark.sql.functions import col
intcols = ["diabetes", "hypertension"]

for col_name in intcols:
    strokeDF = rawstrokeDF.withColumn(col_name, col(col_name).cast(DoubleType()))

# We will also rename the column name 'stroke' as 'label' for 

strokeDF.printSchema()


# ## Transformations

# #### Binarizer

# Lets use divide the BMi into two groups: Obese and healthy. 1 represents 'obese' and 0 represents 'healthy' (If your BMI is 30.0 or higher, it falls within the obese range)
# We will use the Binarizer transformer to create a new variable 'Body Type' (1- obese and 0- healthy) by binarizing the 'BMI' variable by setting the obesity threshold value 30.0. Binarization is used for thresholding numerical feature to binary feature (0 or 1)

from pyspark.ml.feature import Binarizer
binarizer = Binarizer(inputCol="BMI", outputCol="BodyType", threshold=30.0)
binarizedDF = binarizer.transform(strokeDF)
binarizedDF.select('BMI', 'BodyType').show(5,False)


binarizedDF.show(5)


# From the above result we can see that the value of the target feature label is now converted to binary values

# #### Bucketizer

# We now group the patients based on their age group. Here, we will use the Bucketizer transformer. Bucketizer is used for creating group of values of a continuous feature

from pyspark.ml.feature import Bucketizer
# lets define the age age group splits
splits = [0, 25.0, 50.0, 75.0, 100.0]
bucketizer = Bucketizer(inputCol="age", outputCol="ageGroup", splits=splits)
bucketizedDF = bucketizer.transform(binarizedDF)
bucketizedDF.select('age', 'ageGroup').show(10,False)


bucketizedDF.columns


bucketizedDF.select('age', 'ageGroup').show(10,False)


# #### StringIndexer

# There are three categorical variables in our dataset viz., 'gender', 'heart disease' and 'smoking history'. These variables cannot be directly passed to our ML algorithms. We will converet them into indexes and to do that we will use StringIndexer transformer. StringIndexer converts a string column to an index column. The most frequent label gets index 0

from pyspark.ml.feature import StringIndexer
indexers = StringIndexer(inputCols= ['stroke','gender', 'heart_disease', 'smoking_history'], 
                         outputCols=['label', 'gender_indexed', 'heart_disease_indexed', 'smoking_history_indexed'])
strindexedDF = indexers.fit(bucketizedDF).transform(bucketizedDF)
strindexedDF.select('stroke', 'label', 'gender', 'gender_indexed', 'heart_disease', 'heart_disease_indexed', 
                    'smoking_history', 'smoking_history_indexed').show(5, False)


# From the above output you can observe that the categorical columns has got converted to their respective indices columns. The most frequent label gets index 0 and so on ordered by label frequencies

# #### OneHotEncoderEstimator

from pyspark.ml.feature import OneHotEncoder
encoder = OneHotEncoder(inputCols= ["gender_indexed", 'heart_disease_indexed', 'smoking_history_indexed'], 
                         outputCols=["genderVec", 'heart_diseaseVec', 'smoking_historyVec'])
encodedDF = encoder.fit(strindexedDF).transform(strindexedDF)
encodedDF.select('gender_indexed', 'genderVec', 'heart_disease_indexed', 'heart_diseaseVec', 
                    'smoking_history_indexed', 'smoking_historyVec',).show(5, False)


encodedDF.show(5)


# ### VectorAssembler
# MLlib expects all features to be contained within a single column. VectorAssembler combines multiple columns and gives single column as output

# Import VectorAssembler from pyspark.ml.feature package
from pyspark.ml.feature import VectorAssembler
# Create a list of all the variables that you want to create feature vectors
# These features are then further used for training model
features_col = ["age", "diabetes", "hypertension", "BMI", "BodyType", "ageGroup", 
                "genderVec","heart_diseaseVec","smoking_historyVec"]
# Create the VectorAssembler object
assembler = VectorAssembler(inputCols= features_col, outputCol= "features")
assembledDF = assembler.transform(encodedDF)
assembledDF.select("features").show(5, False)


# Now that all the features are vectorized. Let us convert the target variable 'stroke' (integer) in to a label column




# All the features are now in one single feature vector. If you notice, the feature column contains sparse vector. In order to perform scaling on the data, we must convert the sparse vector to dense vector

assembledDF.columns


# ### VectorIndexer
# VectorIndexer automatically identifies the categorical features from the feature vector (output from VectorAssembler). It then indexes categorical features inside of a Vector
# It is the vectorized version of StringIndexer

# Import VectorIndexer from pyspark.ml.feature package
from pyspark.ml.feature import VectorIndexer
# Create a list of all the raw features
# VectorIndexer will automatically identify the categorical columns and index them
featurecol = ['age', 'diabetes','hypertension', 'BMI','BodyType','ageGroup', 
              "gender_indexed", 'heart_disease_indexed', 'smoking_history_indexed']

# Create the VectorAssembler object
assembler = VectorAssembler(inputCols= featurecol, outputCol= "features")
assembledDF = assembler.transform(strindexedDF)

# Create the VectorIndexer object. It only take feature column
vecindexer = VectorIndexer(inputCol= "features", outputCol= "indexed_features")
# Fit the vectorindexer object on the output of the vectorassembler data and transform
vecindexedDF = vecindexer.fit(assembledDF).transform(assembledDF)
vecindexedDF.select("features", "indexed_features").show(5, False)


# VectorIndexer let us skip the one hot encoding stage for encoding the categorical features. As discussed earlier, we should not use one hot encoding on categorical variables for algorithms like decision tree and tree ensembles. VectorIndexer are chosen over OneHotEncoderEstimator in such scenario which allows these algorithms to treat categorical features appropriately

# ### StandardScaler
# StandardScaler scales each value in the feature vector such that the mean is 0 and the standard deviation is 1
# <br>It takes parameters:
# <br>withStd: True by default. Scales the data to unit standard deviation
# <br>withMean: False by default. Centers the data with mean before scaling
# 
# **If you notice the output of vectorassembler data is a sparse vector. This need to be converted into a dense vector befor applying scaling**

from pyspark.sql import functions as F
from pyspark.ml.linalg import Vectors, VectorUDT

# Define a udf that converts sparse vector into dense vector
# You cannot create your own custom function and run that against the data directly. 
# In Spark, You have to register the function first using udf function
sparseToDense = F.udf(lambda v : Vectors.dense(v), VectorUDT())

# We then call the function here passing the column name on which the function has to be applied
densefeatureDF = assembledDF.withColumn('features_array', sparseToDense('features'))

densefeatureDF.select("features", "features_array").show(5, False)


densefeatureDF.printSchema()


# Import StandardScaler from pyspark.ml.feature package
from pyspark.ml.feature import StandardScaler

# Create the StandardScaler object. It only take feature column (dense vector)
stdscaler = StandardScaler(inputCol= "features_array", outputCol= "scaledfeatures")

# Fit the StandardScaler object on the output of the dense vector data and transform
stdscaledDF = stdscaler.fit(densefeatureDF).transform(densefeatureDF)
stdscaledDF.select("scaledfeatures" ).show(5, False)


# From the above output we can see that the features are scaled to unit standard deviation.

stdscaledDF.printSchema()


# ### MinMaxScaler
# For MinMaxScaler you dont need to

# Import MinMaxScaler from pyspark.ml.feature package
from pyspark.ml.feature import MinMaxScaler

# Create the MinMaxScaler object. It only take feature column (dense vector)
mmxscaler = MinMaxScaler(inputCol= "features_array", outputCol= "mmxscaledfeatures", )

# Fit the MinMaxScaler object on the output of the dense vector data and transform
mmxscaledDF = mmxscaler.fit(densefeatureDF).transform(densefeatureDF)
mmxscaledDF.select("mmxscaledfeatures" ).show(5, False)





# ### Normalizer

# Import norm from pyspark.ml.feature package
from pyspark.ml.feature import Normalizer

# Create the norm object. It only take feature column (dense vector)
normscaler = Normalizer(inputCol= "features_array", outputCol= "normscaledfeatures")

# Fit the norm object on the output of the dense vector data and transform
normscaledDF = normscaler.transform(densefeatureDF)
normscaledDF.select("normscaledfeatures" ).show(5, False)


normscaledDF.printSchema()


# ##### You can use any of the above scaled data for training your model

# ## Spark ML Algorithms
# We will now train the ML models with the data that we have worked upon so far. We will build classification model since, given the data, we need to determine if a person will get a stroke or not

# ### Train-Test Split
# We split the output of  data into training and test sets (30% held out for testing)
# Note: This train-test split of for logistic regression

# We spilt the data into 70-30 set
# Training Set - 70% obesevations
# Testing Set - 30% observations
trainDF, testDF =  assembledDF.randomSplit([0.7,0.3], seed = 2020)

# print the count of observations in each set
print("Observations in training set = ", trainDF.count())
print("Observations in testing set = ", testDF.count())


# ### Supervised Learning - Classification 
# #### Logistic Regression

# import the LogisticRegression function from the pyspark.ml.classification package
from pyspark.ml.classification import LogisticRegression

# Build the LogisticRegression object 'lr' by setting the required parameters
lr = LogisticRegression(featuresCol="features", labelCol="label",maxIter= 10,regParam=0.3, elasticNetParam=0.8)

# fit the LogisticRegression object on the training data
lrmodel = lr.fit(trainDF)

#This LogisticRegressionModel can be used as a transformer to perform prediction on the testing data
predictonDF = lrmodel.transform(testDF)

predictonDF.select("label","rawPrediction", "probability", "prediction").show(10,False)


predictonDF.select("label","rawPrediction", "probability", "prediction").show(50,False)


# ##### Model Evaluation

# import BinaryClassificationEvaluator from the pyspark.ml.evaluation package
from pyspark.ml.evaluation import BinaryClassificationEvaluator

# Build the BinaryClassificationEvaluator object 'evaluator'
evaluator = BinaryClassificationEvaluator()

# Calculate the accracy and print its value
accuracy = predictonDF.filter(predictonDF.label == predictonDF.prediction).count()/float(predictonDF.count())
print("Accuracy = ", accuracy)

# evaluate(predictiondataframe) gets area under the ROC curve
print('Area under the ROC curve = ', evaluator.evaluate(predictonDF))


# The accuracy of our model is 98.13 % and the area under the ROC curve is 0.5. You can also find these metrics using the model summary as below

# Create model summary object
lrmodelSummary = lrmodel.summary

# Print the following metrics one by one: 
# 1. Accuracy
# Accuracy is a model summary parameter
print("Accuracy = ", lrmodelSummary.accuracy)
# 2. Area under the ROC curve
# Area under the ROC curve is a model summary parameter
print("Area under the ROC curve = ", lrmodelSummary.areaUnderROC)
# 3. Precision (Positive Predictive Value)
# Precision is a model summary parameter
print("Precision = ", lrmodelSummary.weightedPrecision)
# 4. Recall (True Positive Rate)
# Recall is a model summary parameter
print("Recall = ", lrmodelSummary.weightedRecall)
# 5. F1 Score (F-measure)
# F1 Score is a model summary method
print("F1 Score = ", lrmodelSummary.weightedFMeasure())


# #### Decision Tree

# We spilt the data into 70-30 set
# Training Set - 70% obesevations
# Testing Set - 30% observations
trainDF, testDF =  vecindexedDF.randomSplit([0.7,0.3], seed = 2020)

# print the count of observations in each set
print("Observations in training set = ", trainDF.count())
print("Observations in testing set = ", testDF.count())


# import the DecisionTree function from the pyspark.ml.classification package
from pyspark.ml.classification import DecisionTreeClassifier

# Build the DecisionTree object 'dt' by setting the required parameters
# We will pass the VectorIndexed columns as featureCol for Decision Tree. Since they can handle categorical indexes
dt = DecisionTreeClassifier(featuresCol="indexed_features", labelCol="label",maxDepth= 10)

# fit the DecisionTree object on the training data
dtmodel = dt.fit(trainDF)

#This DecisionTreeModel can be used as a transformer to perform prediction on the testing data
dtpredictonDF = dtmodel.transform(testDF)

dtpredictonDF.select("label","rawPrediction", "probability", "prediction").show(10,False)


# ##### Model Evaluation

# import BinaryClassificationEvaluator from the pyspark.ml.evaluation package
from pyspark.ml.evaluation import BinaryClassificationEvaluator

# Build the BinaryClassificationEvaluator object 'evaluator'
evaluator = BinaryClassificationEvaluator()

# Calculate the accracy and print its value
accuracy = dtpredictonDF.filter(dtpredictonDF.label == dtpredictonDF.prediction).count()/float(dtpredictonDF.count())
print("Accuracy = ", accuracy)

# evaluate(predictiondataframe) gets area under the ROC curve
print('Area under the ROC curve = ', evaluator.evaluate(dtpredictonDF))


# import MulticlassClassificationEvaluator from the pyspark.ml.evaluation package
from pyspark.ml.evaluation import MulticlassClassificationEvaluator

# Build the MulticlassClassificationEvaluator object 'evaluator'
multievaluator = MulticlassClassificationEvaluator(labelCol="label", predictionCol="prediction")

# 1. Accuracy
print("Accuracy: ", multievaluator.evaluate(dtpredictonDF, {evaluator.metricName: "accuracy"})) 
# 2. Area under the ROC curve
print('Area under the ROC curve = ', evaluator.evaluate(dtpredictonDF))
# 3. Precision (Positive Predictive Value)
print("Precision = ", multievaluator.evaluate(dtpredictonDF, {evaluator.metricName: "weightedPrecision"}))
# 4. Recall (True Positive Rate)
print("Recall = ", multievaluator.evaluate(dtpredictonDF, {evaluator.metricName: "weightedRecall"}))
# 5. F1 Score (F-measure)
print("F1 Score = ", multievaluator.evaluate(dtpredictonDF, {evaluator.metricName: "f1"}))


# #### Random Forest

# import the RandomForestClassifier function from the pyspark.ml.classification package
from pyspark.ml.classification import RandomForestClassifier

# Build the RandomForestClassifier object 'dt' by setting the required parameters
# We will pass the VectorIndexed columns as featureCol for Random Forest. Since they can handle categorical indexes
rf = RandomForestClassifier(featuresCol="indexed_features", labelCol="label")

# fit the RandomForestClassifier object on the training data
rfmodel = rf.fit(trainDF)

#This RandomForestClassifierModel can be used as a transformer to perform prediction on the testing data
rfpredictonDF = rfmodel.transform(testDF)

rfpredictonDF.select("label","rawPrediction", "probability", "prediction").show(10,False)


# ##### Model Evaluation

# 1. Accuracy
print("Accuracy: ", multievaluator.evaluate(rfpredictonDF, {evaluator.metricName: "accuracy"})) 
# 2. Area under the ROC curve
print('Area under the ROC curve = ', evaluator.evaluate(rfpredictonDF))
# 3. Precision (Positive Predictive Value)
print("Precision = ", multievaluator.evaluate(rfpredictonDF, {evaluator.metricName: "weightedPrecision"}))
# 4. Recall (True Positive Rate)
print("Recall = ", multievaluator.evaluate(rfpredictonDF, {evaluator.metricName: "weightedRecall"}))
# 5. F1 Score (F-measure)
print("F1 Score = ", multievaluator.evaluate(rfpredictonDF, {evaluator.metricName: "f1"}))


# ### Building Pipeline

# We will split the stroke df into train and test split and pass the training set to the pipeline

# We spilt the data into 70-30 set
# Training Set - 70% obesevations
# Testing Set - 30% observations
trainDF, testDF =  strokeDF.randomSplit([0.7,0.3], seed = 2020)

# print the count of observations in each set
print("Observations in training set = ", trainDF.count())
print("Observations in testing set = ", testDF.count())


# import Pipeline from pyspark.ml package
from pyspark.ml import Pipeline

# Build the pipeline object by providing stages(transformers + Estimator) 
# that you need the dataframe to pass through
# Transfoermers - binarizer, bucketizer, indexers, encoder, assembler
# Estimator - lr
lrpipeline = Pipeline(stages=[binarizer, bucketizer, indexers, encoder, assembler, lr])

# fit the pipeline for the trainind data
lrpipelinemodel = lrpipeline.fit(trainDF)

# transform the data
lrpipelinepredicted = lrpipelinemodel.transform(testDF)

# view some of the columns generated
lrpipelinepredicted.select('label', 'rawPrediction', 'probability', 'prediction').show(10)


# Build the MulticlassClassificationEvaluator object 'evaluator'
multievaluator = MulticlassClassificationEvaluator(labelCol="label", predictionCol="prediction")

# 1. Accuracy
print("Accuracy: ", multievaluator.evaluate(lrpipelinepredicted, {evaluator.metricName: "accuracy"})) 
# 2. Area under the ROC curve
print('Area under the ROC curve = ', evaluator.evaluate(lrpipelinepredicted))
# 3. Precision (Positive Predictive Value)
print("Precision = ", multievaluator.evaluate(lrpipelinepredicted, {evaluator.metricName: "weightedPrecision"}))
# 4. Recall (True Positive Rate)
print("Recall = ", multievaluator.evaluate(lrpipelinepredicted, {evaluator.metricName: "weightedRecall"}))
# 5. F1 Score (F-measure)
print("F1 Score = ", multievaluator.evaluate(lrpipelinepredicted, {evaluator.metricName: "f1"}))


# ### Model Persistence
# Model persistence means saving your model to a disk. After you finalize your model for prediction depending upon the performance, you need to save the model to the disk. Let's say, you finalize 'lrpipelinemodel' to be used for in production environment i.e. in your application. We use the following code to save it.

# ##### Saving pipeline model

# use save() method to save the model
# write().overwrite() is usually used when you want to replace the older model with a new one
# It might happen that you wish to retrain your model and save it at the same the place
lrpipelinemodel.write().overwrite().save("lrmodel")


# ##### Loading pipeline model

# import PipelineModel from pyspark.ml package
from pyspark.ml import PipelineModel

# load the model from the location it is stored
# The loaded model acts as PipelineModel
pipemodel = PipelineModel.load("lrmodel")

# use the PipelineModel object to perform prediciton on test data. 
# Use .transform() to perfrom prediction
prediction = pipemodel.transform(testDF)

# print the results
prediction.select('label', 'rawPrediction', 'probability', 'prediction').show(5)




