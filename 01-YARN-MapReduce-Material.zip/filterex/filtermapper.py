#!/usr/bin/env python3
import sys

#--- get each lines from stdin ---
for line in sys.stdin:
    columns=line.split('\t')
    if columns[3].strip()=='TX':
        print(line.strip())
