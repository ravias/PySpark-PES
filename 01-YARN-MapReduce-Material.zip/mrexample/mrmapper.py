#!/usr/bin/env python3
import sys

#--- get each lines from stdin ---
for line in sys.stdin:
    columns=line.split('\t')
    if len(columns[2])>0:
        print('%s\t%s' % (columns[2],"1"))
